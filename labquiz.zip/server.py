#!/usr/bin/env python3
# 单机版：同时提供刷题页面、账号接口、管理后台（只用 Python 标准库）。

import json
import os
import random
import re
import sqlite3
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

BASE = os.path.dirname(os.path.abspath(__file__))
PUBLIC = os.path.join(BASE, "public")
DB_PATH = os.environ.get("LQ_DB", os.path.join(BASE, "labquiz.db"))
ADMIN_KEY = os.environ.get("LQ_ADMIN_KEY", "")
ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
LOCK = threading.Lock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS accounts (
  id TEXT PRIMARY KEY, nickname TEXT NOT NULL, device_id TEXT NOT NULL,
  device_fp TEXT, created_at INTEGER NOT NULL, last_seen INTEGER,
  status TEXT NOT NULL DEFAULT 'active', ban_reason TEXT, banned_at INTEGER);
CREATE TABLE IF NOT EXISTS devices (
  account_id TEXT NOT NULL, device_id TEXT NOT NULL, first_seen INTEGER NOT NULL,
  last_seen INTEGER NOT NULL, ok INTEGER NOT NULL DEFAULT 1, ua TEXT, ip TEXT,
  PRIMARY KEY (account_id, device_id));
CREATE TABLE IF NOT EXISTS logins (
  id INTEGER PRIMARY KEY AUTOINCREMENT, account_id TEXT NOT NULL, device_id TEXT NOT NULL,
  ts INTEGER NOT NULL, ok INTEGER NOT NULL, reason TEXT, ua TEXT, ip TEXT);
CREATE TABLE IF NOT EXISTS violations (
  id INTEGER PRIMARY KEY AUTOINCREMENT, account_id TEXT NOT NULL, kind TEXT NOT NULL,
  detail TEXT, ts INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_logins_account ON logins(account_id, ts);
CREATE INDEX IF NOT EXISTS idx_violations_account ON violations(account_id, ts);
"""


def db():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with db() as conn:
        conn.executescript(SCHEMA)


def new_id():
    return "LQ-" + "".join(random.choice(ALPHABET) for _ in range(6))


def touch(conn, account_id, device_id, ts, ua, ip, ok):
    conn.execute(
        """INSERT INTO devices (account_id, device_id, first_seen, last_seen, ok, ua, ip)
           VALUES (?,?,?,?,?,?,?)
           ON CONFLICT(account_id, device_id) DO UPDATE SET
             last_seen=excluded.last_seen, ok=excluded.ok, ua=excluded.ua, ip=excluded.ip""",
        (account_id, device_id, ts, ts, ok, ua, ip),
    )


def log(conn, account_id, device_id, ok, reason, ua, ip):
    conn.execute(
        "INSERT INTO logins (account_id, device_id, ts, ok, reason, ua, ip) VALUES (?,?,?,?,?,?,?)",
        (account_id, device_id, int(time.time() * 1000), ok, reason, ua, ip),
    )


def register(body, ua, ip):
    nickname = str(body.get("nickname", "")).strip()[:20]
    device = str(body.get("deviceId", "")).strip()
    fp = str(body.get("fp", ""))[:64]
    if not nickname:
        return 400, {"ok": False, "error": "nickname_required"}
    if not re.fullmatch(r"[A-Za-z0-9_-]{8,80}", device):
        return 400, {"ok": False, "error": "device_required"}
    with LOCK, db() as conn:
        row = conn.execute(
            "SELECT id, nickname FROM accounts WHERE device_id=? LIMIT 1", (device,)
        ).fetchone()
        if row:
            return 409, {"ok": False, "error": "device_already_registered",
                         "account": {"id": row["id"], "nickname": row["nickname"]}}
        same_fp = None
        if fp:
            same_fp = conn.execute(
                "SELECT id FROM accounts WHERE device_fp=? LIMIT 1", (fp,)
            ).fetchone()
        acc_id = new_id()
        for _ in range(6):
            if not conn.execute("SELECT 1 FROM accounts WHERE id=?", (acc_id,)).fetchone():
                break
            acc_id = new_id()
        ts = int(time.time() * 1000)
        conn.execute(
            "INSERT INTO accounts (id,nickname,device_id,device_fp,created_at,last_seen,status)"
            " VALUES (?,?,?,?,?,?, 'active')",
            (acc_id, nickname, device, fp, ts, ts),
        )
        if same_fp:
            conn.execute(
                "INSERT INTO violations (account_id,kind,detail,ts) VALUES (?,?,?,?)",
                (acc_id, "reregister_same_fp", same_fp["id"], ts),
            )
        touch(conn, acc_id, device, ts, ua, ip, 1)
        log(conn, acc_id, device, 1, "register", ua, ip)
        return 200, {"ok": True, "account": {"id": acc_id, "nickname": nickname, "createdAt": ts}}


def login(body, ua, ip):
    acc_id = str(body.get("accountId", "")).strip().upper()
    device = str(body.get("deviceId", "")).strip()
    if not acc_id or not device:
        return 400, {"ok": False, "error": "missing"}
    with LOCK, db() as conn:
        row = conn.execute("SELECT * FROM accounts WHERE id=?", (acc_id,)).fetchone()
        if not row:
            return 404, {"ok": False, "error": "account_not_found"}
        if row["status"] == "banned":
            return 403, {"ok": False, "error": "banned", "reason": row["ban_reason"] or ""}
        ts = int(time.time() * 1000)
        if row["device_id"] != device:
            touch(conn, acc_id, device, ts, ua, ip, 0)
            log(conn, acc_id, device, 0, "multi_device", ua, ip)
            conn.execute(
                "INSERT INTO violations (account_id,kind,detail,ts) VALUES (?,?,?,?)",
                (acc_id, "multi_device", device[:8], ts),
            )
            return 403, {"ok": False, "error": "multi_device",
                         "message": "该账号已绑定其他设备，已记录一次多端登录。"}
        conn.execute("UPDATE accounts SET last_seen=? WHERE id=?", (ts, acc_id))
        touch(conn, acc_id, device, ts, ua, ip, 1)
        log(conn, acc_id, device, 1, "login", ua, ip)
        return 200, {"ok": True, "account": {"id": row["id"], "nickname": row["nickname"],
                                             "createdAt": row["created_at"]}}


def admin(path, body, key):
    if not ADMIN_KEY or key != ADMIN_KEY:
        return 401, {"ok": False, "error": "unauthorized"}
    with LOCK, db() as conn:
        if path == "/api/admin/accounts":
            rows = conn.execute(
                """SELECT a.id,a.nickname,a.status,a.created_at,a.last_seen,a.ban_reason,
                   (SELECT COUNT(*) FROM devices d WHERE d.account_id=a.id) device_count,
                   (SELECT COUNT(*) FROM violations v WHERE v.account_id=a.id) violation_count,
                   (SELECT MAX(ts) FROM violations v WHERE v.account_id=a.id) last_violation
                   FROM accounts a ORDER BY a.created_at DESC"""
            ).fetchall()
            return 200, {"ok": True, "accounts": [dict(r) for r in rows]}
        if path == "/api/admin/ban":
            conn.execute(
                "UPDATE accounts SET status='banned', ban_reason=?, banned_at=? WHERE id=?",
                (str(body.get("reason", "违规"))[:200], int(time.time() * 1000),
                 str(body.get("id", ""))),
            )
            return 200, {"ok": True}
        if path == "/api/admin/unban":
            conn.execute(
                "UPDATE accounts SET status='active', ban_reason=NULL, banned_at=NULL WHERE id=?",
                (str(body.get("id", "")),),
            )
            return 200, {"ok": True}
        if path == "/api/admin/delete":
            acc_id = str(body.get("id", ""))
            conn.execute("DELETE FROM devices WHERE account_id=?", (acc_id,))
            conn.execute("DELETE FROM logins WHERE account_id=?", (acc_id,))
            conn.execute("DELETE FROM violations WHERE account_id=?", (acc_id,))
            conn.execute("DELETE FROM accounts WHERE id=?", (acc_id,))
            return 200, {"ok": True}
        if path == "/api/admin/rebind":
            acc_id = str(body.get("id", ""))
            dev = conn.execute(
                "SELECT device_id FROM devices WHERE account_id=? AND ok=0"
                " ORDER BY last_seen DESC LIMIT 1", (acc_id,)
            ).fetchone()
            if not dev:
                return 400, {"ok": False, "error": "no_pending_device"}
            conn.execute("UPDATE accounts SET device_id=?, status='active' WHERE id=?",
                         (dev["device_id"], acc_id))
            return 200, {"ok": True}
    return 404, {"ok": False, "error": "not_found"}


def banned_list():
    with db() as conn:
        rows = conn.execute("SELECT id, ban_reason FROM accounts WHERE status='banned'").fetchall()
        return 200, {"ok": True,
                     "bans": [{"id": r["id"], "reason": r["ban_reason"] or ""} for r in rows]}


class Handler(BaseHTTPRequestHandler):
    server_version = "LabQuiz/1.0"

    def _send(self, status, body, ctype="application/json; charset=utf-8"):
        data = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type,X-Admin-Key")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def do_OPTIONS(self):
        self._send(204, b"")

    def do_GET(self):
        path = urlparse(self.path).path
        if path in ("/", "/index.html"):
            return self._file(os.path.join(PUBLIC, "index.html"), "text/html; charset=utf-8")
        if path == "/admin":
            return self._file(os.path.join(BASE, "admin.html"), "text/html; charset=utf-8")
        if path == "/api/bans":
            return self._send(*banned_list())
        if path == "/health":
            return self._send(200, {"ok": True, "service": "lab-quiz-server",
                                    "time": int(time.time())})
        if path.startswith("/api/admin/"):
            return self._send(*admin(path, {}, self.headers.get("X-Admin-Key", "")))
        return self._send(404, {"ok": False, "error": "not_found"})

    def do_POST(self):
        path = urlparse(self.path).path
        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length) if length else b"{}"
        try:
            body = json.loads(raw.decode() or "{}")
        except Exception:
            body = {}
        ua = (self.headers.get("User-Agent") or "")[:200]
        ip = self.client_address[0]
        if path == "/api/register":
            return self._send(*register(body, ua, ip))
        if path == "/api/login":
            return self._send(*login(body, ua, ip))
        if path.startswith("/api/admin/"):
            return self._send(*admin(path, body, self.headers.get("X-Admin-Key", "")))
        return self._send(404, {"ok": False, "error": "not_found"})

    def _file(self, path, ctype):
        try:
            with open(path, "rb") as fh:
                self._send(200, fh.read(), ctype)
        except OSError:
            self._send(404, "not found", "text/plain; charset=utf-8")

    def log_message(self, fmt, *args):
        pass


def main():
    init_db()
    port = int(os.environ.get("PORT", "8000"))
    srv = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    print(f"Lab Quiz server on http://0.0.0.0:{port}  admin key: {ADMIN_KEY or '(unset)'}")
    srv.serve_forever()


if __name__ == "__main__":
    main()
