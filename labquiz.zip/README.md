# 实验室安全刷题 · 国内自建版

一个 Python 程序同时提供：刷题页面、账号接口、管理后台、SQLite 数据库。
不依赖 GitHub、Cloudflare 等境外服务，**国内网络可直接访问，无需 VPN**。

## 一、准备

- 一台国内云服务器（阿里云 / 腾讯云轻量应用服务器，1 核 1G 足够，Ubuntu 22.04 或 Debian 12）。
- 在云控制台的「防火墙 / 安全组」里放行 TCP **8000** 端口。

## 二、部署（3 条命令）

把本压缩包上传到服务器后：

```bash
sudo apt update && sudo apt install -y python3        # 已装可跳过
cd /opt && sudo mkdir -p labquiz && sudo tar -xzf ~/labquiz.tar.gz -C labquiz
cd /opt/labquiz
export LQ_ADMIN_KEY='换成你自己的管理密钥'
sudo LQ_ADMIN_KEY="$LQ_ADMIN_KEY" python3 server.py
```

浏览器打开 `http://服务器公网IP:8000/` 即可使用；
管理后台 `http://服务器公网IP:8000/admin`，输入上面的 `LQ_ADMIN_KEY`。

## 三、长期运行（systemd）

```bash
sudo cp labquiz.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now labquiz
sudo systemctl status labquiz
```

> 记得先编辑 `labquiz.service` 里的 `LQ_ADMIN_KEY`。

## 四、HTTPS（可选）

- 有已备案域名：用 Nginx 或 Caddy 反向代理到 `127.0.0.1:8000`，Caddy 会自动申请证书。
- 没有域名：直接用 `http://IP:8000` 也能用（页面与接口同源，不会出现混合内容问题）。

## 五、数据与维护

- 数据全部在 `labquiz.db`（SQLite），**定期备份这个文件**即可。
- 更新题库/页面：替换 `public/index.html`，刷新页面即可。
- 重置所有账号：停服后删除 `labquiz.db`，重启会自动重建空库。

## 六、账号规则

- 每台设备首次进入创建一个账号（服务器记录设备 ID），同一设备不能再建第二个。
- 同一账号换设备登录会被拒绝并记一次违规。
- 管理后台可封禁 / 解封 / 重绑设备 / 删除账号。
- 统一入口密码仍是 `lab2026`。
